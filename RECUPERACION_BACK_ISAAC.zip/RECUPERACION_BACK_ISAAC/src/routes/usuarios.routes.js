const router = require('express').Router();
const c = require('../controllers/usuarios.controller');
const upload = require('../middlewares/upload');

router.post('/registro', upload, c.registrar);
router.post('/verificar', c.verificar);
router.post('/reenviar-codigo', c.reenviarCodigo);

router.get('/', c.listar);
router.get('/:id', c.obtener);
router.put('/:id', upload, c.actualizar);
router.delete('/:id', c.eliminar);

module.exports = router;
