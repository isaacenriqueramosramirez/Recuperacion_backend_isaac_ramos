const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const Usuario = require('../models/Usuario');
const AppError = require('../utils/AppError');
const { subirImagen, eliminarImagen } = require('../config/cloudinary');
const { enviarCodigo } = require('../utils/mailer');
const { validarUsuario, EMAIL_RE } = require('../utils/validaciones');

const MIN = () => Number(process.env.CODE_EXPIRES_MIN) || 10;
const generarCodigo = () => String(crypto.randomInt(100000, 1000000));
const expira = () => new Date(Date.now() + MIN() * 60 * 1000);
const validarId = (id) => {
  if (!mongoose.isValidObjectId(id)) throw new AppError('ID inválido', 400);
};

// ---------- REGISTRO ----------
exports.registrar = async (req, res, next) => {
  let imagen;
  try {
    const errores = validarUsuario(req.body);
    if (!req.file) errores.push('La fotografía de perfil es obligatoria (campo fotoPerfil)');
    if (errores.length) throw new AppError('Datos inválidos', 400, errores);

    const email = req.body.email.toLowerCase().trim();
    if (await Usuario.exists({ email })) throw new AppError('El correo ya está registrado', 409);

    imagen = await subirImagen(req.file.buffer);
    const codigo = generarCodigo();

    const usuario = await Usuario.create({
      ...req.body,
      email,
      password: await bcrypt.hash(req.body.password, 10),
      fotoPerfil: imagen.secure_url,
      cloudinaryPublicId: imagen.public_id,
      codigoVerificacion: codigo,
      codigoExpira: expira(),
      isVerified: false,
    });

    try {
      await enviarCodigo(email, usuario.nombre, codigo);
    } catch (e) {
      // Si no se pudo enviar el correo, se revierte el registro
      await Usuario.findByIdAndDelete(usuario._id);
      await eliminarImagen(imagen.public_id).catch(() => {});
      imagen = null;
      throw new AppError('No se pudo enviar el código de verificación. Intenta de nuevo', 502);
    }

    res.status(201).json({
      ok: true,
      mensaje: `Usuario registrado. Revisa tu correo: el código vence en ${MIN()} minutos`,
      usuario: { id: usuario._id, email, isVerified: false, fotoPerfil: usuario.fotoPerfil },
    });
  } catch (err) {
    // Limpieza de imagen huérfana si falló antes de guardar
    if (imagen) await eliminarImagen(imagen.public_id).catch(() => {});
    next(err);
  }
};

// ---------- VERIFICAR CÓDIGO ----------
exports.verificar = async (req, res, next) => {
  try {
    const { email, codigo } = req.body;
    if (!email || !codigo) throw new AppError("Se requieren 'email' y 'codigo'", 400);
    if (!EMAIL_RE.test(email)) throw new AppError('El formato del correo no es válido', 400);
    if (!/^\d{6}$/.test(String(codigo))) throw new AppError('El código debe tener 6 dígitos', 400);

    const u = await Usuario.findOne({ email: email.toLowerCase() }).select(
      '+codigoVerificacion +codigoExpira'
    );
    if (!u) throw new AppError('Usuario no encontrado', 404);
    if (u.isVerified) throw new AppError('La cuenta ya está verificada', 409);
    if (!u.codigoExpira || u.codigoExpira < new Date())
      throw new AppError('El código ha expirado. Solicita uno nuevo', 410);
    if (u.codigoVerificacion !== String(codigo)) throw new AppError('Código incorrecto', 400);

    u.isVerified = true;
    u.codigoVerificacion = undefined;
    u.codigoExpira = undefined;
    await u.save();

    res.json({ ok: true, mensaje: 'Cuenta verificada correctamente' });
  } catch (err) {
    next(err);
  }
};

// ---------- REENVIAR CÓDIGO ----------
exports.reenviarCodigo = async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email || !EMAIL_RE.test(email)) throw new AppError('Correo inválido', 400);

    const u = await Usuario.findOne({ email: email.toLowerCase() });
    if (!u) throw new AppError('Usuario no encontrado', 404);
    if (u.isVerified) throw new AppError('La cuenta ya está verificada', 409);

    const codigo = generarCodigo();
    u.codigoVerificacion = codigo;
    u.codigoExpira = expira();
    await u.save();

    await enviarCodigo(u.email, u.nombre, codigo).catch(() => {
      throw new AppError('No se pudo enviar el código', 502);
    });
    res.json({ ok: true, mensaje: 'Nuevo código enviado al correo' });
  } catch (err) {
    next(err);
  }
};

// ---------- CRUD ----------
exports.listar = async (req, res, next) => {
  try {
    const usuarios = await Usuario.find().sort({ createdAt: -1 });
    res.json({ ok: true, total: usuarios.length, usuarios });
  } catch (err) {
    next(err);
  }
};

exports.obtener = async (req, res, next) => {
  try {
    validarId(req.params.id);
    const u = await Usuario.findById(req.params.id);
    if (!u) throw new AppError('Usuario no encontrado', 404);
    res.json({ ok: true, usuario: u });
  } catch (err) {
    next(err);
  }
};

exports.actualizar = async (req, res, next) => {
  let nueva;
  try {
    validarId(req.params.id);
    const u = await Usuario.findById(req.params.id);
    if (!u) throw new AppError('Usuario no encontrado', 404);

    const errores = validarUsuario(req.body, { parcial: true });
    if (errores.length) throw new AppError('Datos inválidos', 400, errores);

    // Campos no modificables desde aquí
    ['isVerified', 'codigoVerificacion', 'codigoExpira', 'fotoPerfil', 'cloudinaryPublicId']
      .forEach((c) => delete req.body[c]);

    if (req.body.email) {
      const email = req.body.email.toLowerCase().trim();
      const otro = await Usuario.findOne({ email, _id: { $ne: u._id } });
      if (otro) throw new AppError('El correo ya está registrado', 409);
      req.body.email = email;
    }
    if (req.body.password) req.body.password = await bcrypt.hash(req.body.password, 10);

    const publicIdAnterior = u.cloudinaryPublicId;
    if (req.file) {
      nueva = await subirImagen(req.file.buffer);
      u.fotoPerfil = nueva.secure_url;
      u.cloudinaryPublicId = nueva.public_id;
    }

    u.set(req.body);
    await u.save();

    // Solo se borra la imagen anterior cuando todo se guardó bien
    if (nueva) {
      await eliminarImagen(publicIdAnterior).catch(() => {});
      nueva = null;
    }

    res.json({ ok: true, mensaje: 'Usuario actualizado', usuario: await Usuario.findById(u._id) });
  } catch (err) {
    if (nueva) await eliminarImagen(nueva.public_id).catch(() => {});
    next(err);
  }
};

exports.eliminar = async (req, res, next) => {
  try {
    validarId(req.params.id);
    const u = await Usuario.findByIdAndDelete(req.params.id);
    if (!u) throw new AppError('Usuario no encontrado', 404);
    await eliminarImagen(u.cloudinaryPublicId).catch(() => {});
    res.json({ ok: true, mensaje: 'Usuario y fotografía eliminados' });
  } catch (err) {
    next(err);
  }
};
