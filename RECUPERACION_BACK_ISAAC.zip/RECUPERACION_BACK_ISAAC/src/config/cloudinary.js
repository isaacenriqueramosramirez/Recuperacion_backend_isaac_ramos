const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Sube un buffer (multer memoryStorage) a Cloudinary
const subirImagen = (buffer, folder = 'usuarios') =>
  new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      { folder, resource_type: 'image' },
      (err, result) => (err ? reject(err) : resolve(result))
    );
    stream.end(buffer);
  });

const eliminarImagen = (publicId) =>
  publicId ? cloudinary.uploader.destroy(publicId) : Promise.resolve();

module.exports = { subirImagen, eliminarImagen };
