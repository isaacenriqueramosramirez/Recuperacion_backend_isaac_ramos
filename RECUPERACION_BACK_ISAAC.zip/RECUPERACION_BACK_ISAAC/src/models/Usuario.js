const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
    apellido: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    telefono: { type: String, required: true, trim: true },
    fechaNacimiento: { type: Date, required: true },
    fotoPerfil: { type: String, required: true },
    cloudinaryPublicId: { type: String, required: true },
    codigoVerificacion: { type: String, select: false },
    codigoExpira: { type: Date, select: false },
    isVerified: { type: Boolean, default: false },
  },
  { collection: 'usuarios', timestamps: true }
);

module.exports = mongoose.model('Usuario', usuarioSchema);
