const multer = require('multer');
const AppError = require('../utils/AppError');

const TIPOS = ['image/jpeg', 'image/png', 'image/webp'];

module.exports = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    if (!TIPOS.includes(file.mimetype)) {
      return cb(new AppError('La fotografía debe ser JPG, PNG o WEBP', 400));
    }
    cb(null, true);
  },
}).single('fotoPerfil');
