require('dotenv').config();
const express = require('express');
const conectarDB = require('./config/db');
const errorHandler = require('./middlewares/errorHandler');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/usuarios', require('./routes/usuarios.routes'));
app.use((req, res) => res.status(404).json({ ok: false, mensaje: 'Ruta no encontrada' }));
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
conectarDB()
  .then(() => app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`)))
  .catch((e) => {
    console.error('Error al conectar MongoDB:', e.message);
    process.exit(1);
  });
